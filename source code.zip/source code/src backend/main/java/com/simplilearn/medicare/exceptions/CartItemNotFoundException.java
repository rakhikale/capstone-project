package com.simplilearn.medicare.exceptions;

public class CartItemNotFoundException extends Exception{
	public CartItemNotFoundException(String message) {
		super(message);
	}
}
